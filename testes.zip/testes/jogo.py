import pygame, random
from pygame.locals import *

score = 0
def ScreenText(text, size, color):
    font = pygame.font.SysFont('Arial', size, True, False, )
    msg = f'{text}'
    screen_text = font.render(msg, True, color, 'yellow')
    return screen_text


# método construtor, tem a responsabilidade de criar o objeto daquela classe
pygame.init()

# area da musica de fundo do jogo
pygame.mixer.music.set_volume(0.1)
musica = pygame.mixer.music.load("musica fundo.mp3")
pygame.mixer.music.play()

# area da musica de cada vez que mulamos
pulo = pygame.mixer.Sound("Pulo1.wav")
pulo.set_volume(0.08)

# area da musica quando fizemos uma puntuação
puntuacao = pygame.mixer.Sound("pontuacao.wav")

# area de musica quando morremos
morreu = pygame.mixer.Sound("batida.wav")

# Tem que ser em MAIUSCULO porque é uma variavel constante, uma vareavel que nunca muda
# Tamanho da tela do jogo
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 800

# Velocidade de queda do passaro
SPEED = 10

# define a gravidade de cada "pulo" do passaro
GRAVITY = 1

# velocidade que é rodado o jogo
GAME_SPEED = 10

# WIDTH define a largura do chao e HEIGHT define a altura do chao
GROUND_WIDTH = 2 * SCREEN_WIDTH
GROUND_HEIGHT = 100

# WIDTH define a largura do cano e HEIGHT defie a altura do cano
PIPE_WIDTH = 80
PIPE_HEIGHT = 500

#PIPE_GAP define o espaçamento entre o cano de cima com o de baixo
PIPE_GAP = 200

# Sprite serve para fazer varias funcionalidade, como a contrucao internamente (vida ao passaro)
# class (orientacao a objetos)
class Bird(pygame.sprite.Sprite):

    #Inicializador da class
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        # convert_alpha serve para tirar os pixel transparente
        self.images = [pygame.image.load('bluebird-upflap.png').convert_alpha(),
                       pygame.image.load('bluebird-midflap.png').convert_alpha(),
                       pygame.image.load('bluebird-downflap.png').convert_alpha()]

        # defini a velocidade do passaro
        self.speed = SPEED

        self.current_image = 0

        self.image = pygame.image.load('bluebird-upflap.png').convert_alpha()
        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        # O posicionamento do passaro, colocamos / 2 para ele pegar a metado do WIDTH e do HEIGHT para ficar no meio dos dois
        self.rect[0] = SCREEN_WIDTH / 2
        self.rect[1] = SCREEN_HEIGHT / 2

    # faz um loop repetitivo da imagem do passaro
    def update(self):
        self.current_image = (self.current_image + 1) % 3
        self.image = self.images[ self.current_image ]

        # define a gravidade de cada "pulo" do passaro
        self.speed += GRAVITY

        # Atualizar altura do passaro
        self.rect[1] += self.speed
    
    def bump(self):
        self.speed = -SPEED
        pulo.play()

# Contrucao internamente (fazendo aparecer os canos)
class Pipe(pygame.sprite.Sprite):

    #Inicializador da class
    def __init__(self, inverted, xpos, ysize):
        pygame.sprite.Sprite.__init__(self)

        puntuacao.play()

        self.image = pygame.image.load('pipe-red.png').convert_alpha()
        # Estica a imagem do cano
        self.image = pygame.transform.scale(self.image, (PIPE_WIDTH,PIPE_HEIGHT))

        self.rect = self.image.get_rect()
        self.rect[0] = xpos
        
        # Faz a inversao do cano (facilita, pois nao precisa criar outra variavel)
        if inverted:
            self.image = pygame.transform.flip(self.image, False, True)
            self.rect[1] = - (self.rect[3] - ysize)
        else:
            self.rect[1] = SCREEN_HEIGHT - ysize

        self.mask = pygame.mask.from_surface(self.image)


    # Canos vao ser gerado conforme a velocidade do jogo
    def update(self):
        self.rect[0] -= GAME_SPEED

## Sprite serve para fazer varias funcionalidade, como a contrucao internamente (movimentacao do chão)
class Ground(pygame.sprite.Sprite):

    #Inicializador da class
    def __init__(self, xpos):
        pygame.sprite.Sprite.__init__(self)


        self.image = pygame.image.load('base.png').convert_alpha()
        self.image = pygame.transform.scale(self.image, (GROUND_WIDTH, GROUND_HEIGHT))

        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        # xpos é o eixo X do jogo, onde o chao é criado novamente, infinitamente
        self.rect[0] = xpos
        # Altura do chão
        self.rect[1] = SCREEN_HEIGHT - GROUND_HEIGHT

    # Movimentacao do chão
    def update(self):
        self.rect[0] -= GAME_SPEED

# V erifica se a imagem ja saiu da tela
def is_off_screen(sprite):
    return sprite.rect[0] < -(sprite.rect[2])

def get_random_pipes(xpos):
    # Geração aleatoria onde vai ser feita a geracao da abertura do cano para passar
    size = random.randint(100, 400) 
    pipe = Pipe(False, xpos, size)
    pipe_inverted = Pipe(True, xpos, SCREEN_HEIGHT - size - PIPE_GAP)
    return (pipe, pipe_inverted)
    


# Aqui é um tupla, que representa a largura e a altura do jogo, sem essa tupla nao é formado a tela do jogo
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Imagem de fundo do jogo
BACKGROUND = pygame.image.load('background-day.png')
# fazemos uma tupla para fazer o redimensionamento do tamanho da imagem
BACKGROUND = pygame.transform.scale(BACKGROUND, ( SCREEN_WIDTH, SCREEN_HEIGHT))


bird_group = pygame.sprite.Group()
bird = Bird()
bird_group.add(bird)

ground_group = pygame.sprite.Group()
for i in range(2):
    ground = Ground(GROUND_WIDTH * i)
    ground_group.add(ground)

pipe_group = pygame.sprite.Group()
for i in range(2):
    # Onde vai começar a ser gerado os cano
    pipes = get_random_pipes(SCREEN_WIDTH * i + 600)
    pipe_group.add(pipes[0])
    pipe_group.add(pipes[1])

# clock vai definir quantos FPS vamos querer no jogo, para definir a velocidade
clock = pygame.time.Clock()

while True:
    clock.tick(30)
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        # KEYDOWN serve para fazer o reconhecimento se apertou alguma tecla
        if event.type == KEYDOWN:
            if event.key == K_SPACE:
                bird.bump()

    # Definir por onde começa a imagem de fundo, colocando 0, 0 definimos que a imagem comece pelo pixel 0
    screen.blit(BACKGROUND, (0, 0))

    if is_off_screen(ground_group.sprites()[0]):
        ground_group.remove(ground_group.sprites()[0])

        new_ground = Ground(GROUND_WIDTH - 20)
        ground_group.add(new_ground)

    if is_off_screen(pipe_group.sprites()[0]):
        pipe_group.remove(pipe_group.sprites()[0])
        pipe_group.remove(pipe_group.sprites()[0])

        pipes = get_random_pipes(SCREEN_WIDTH * 2)

        pipe_group.add(pipes[0])
        pipe_group.add(pipes[1])

    bird_group.update()
    ground_group.update()
    pipe_group.update()

    bird_group.draw(screen)
    pipe_group.draw(screen)
    ground_group.draw(screen)
    #sistema de score
    score += 1
    score_text = ScreenText(score, 40, (0,0,0))
    screen.blit(score_text, (170, 100 ))

    pygame.display.update()

    # identifica quando o passaro bate no chao ou no cano para finalizar o jogo
    if (pygame.sprite.groupcollide(bird_group, ground_group, False, False, pygame.sprite.collide_mask) or
       pygame.sprite.groupcollide(bird_group, pipe_group, False, False, pygame.sprite.collide_mask)):
        pygame.mixer.music.stop()
        morreu.play()
        # Finaliza o jogo (GAMER OVER)
        input()
        break

